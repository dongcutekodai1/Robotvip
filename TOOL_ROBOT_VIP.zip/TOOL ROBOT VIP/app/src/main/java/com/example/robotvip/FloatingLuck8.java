package com.example.robotvip;

public class FloatingLuck8 extends BaseFloatingService {
    @Override
    protected String getApiUrl() {
        return "https://tooltxvip.pro/api.php?game=luck8";
    }
}
