package com.example.robotvip;

public class Floating789 extends BaseFloatingService {
    @Override
    protected String getApiUrl() {
        return "https://tooltxvip.pro/api.php?game=789club";
    }
}
