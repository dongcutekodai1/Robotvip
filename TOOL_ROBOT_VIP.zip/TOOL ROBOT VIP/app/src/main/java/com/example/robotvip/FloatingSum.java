package com.example.robotvip;

public class FloatingSum extends BaseFloatingService {
    @Override
    protected String getApiUrl() {
        return "https://tooltxvip.pro/api.php?game=sumclub";
    }
}
