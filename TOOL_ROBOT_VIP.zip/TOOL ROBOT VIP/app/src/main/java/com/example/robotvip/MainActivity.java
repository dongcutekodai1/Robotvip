package com.example.robotvip;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int[] gameIcons = {
		R.drawable.ic_sunwin,
		R.drawable.ic_789,
		R.drawable.ic_hit,
		R.drawable.ic_b52,
		R.drawable.ic_68gb,
		R.drawable.ic_sum,
		R.drawable.ic_luck8
    };

    String[] gameNames = {
		"SunWin", "789Club", "HitClub", "B52", "68Game", "SumClub", "Luck8"
    };

    private static final int REQUEST_OVERLAY_PERMISSION = 1234;
    private Class<?> pendingServiceClass = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ BẮT BUỘC LOGIN
        SharedPreferences prefs = getSharedPreferences("MyApp", Context.MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);

        if (!isLoggedIn) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // 👉 Nút Đăng xuất
        Button btnLogout = findViewById(R.id.btnLogout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						SharedPreferences prefs = getSharedPreferences("MyApp", Context.MODE_PRIVATE);
						prefs.edit().clear().apply();

						Intent intent = new Intent(MainActivity.this, LoginActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
						startActivity(intent);
						finish();
					}
				});
        }

        // 👉 Nút menu
        ImageView btnMenu = findViewById(R.id.btnMenu);
        if (btnMenu != null) {
            btnMenu.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						showPriceMenu();
					}
				});
        }

        // 👉 Grid game
        GridLayout gridLayout = findViewById(R.id.gridGames);
        if (gridLayout == null) return;
        gridLayout.setBackgroundResource(R.drawable.ic_nen);

        for (int i = 0; i < gameIcons.length; i++) {
            final int index = i;

            ImageView imageView = new ImageView(this);
            imageView.setImageResource(gameIcons[i]);

            int sizeInDp = 95;
            int marginInDp = 10;

            int sizeInPx = (int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, sizeInDp, getResources().getDisplayMetrics());
            int marginInPx = (int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, marginInDp, getResources().getDisplayMetrics());

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = sizeInPx;
            params.height = sizeInPx;
            params.setMargins(marginInPx, marginInPx, marginInPx, marginInPx);

            imageView.setLayoutParams(params);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

            // 👉 Click icon game
            imageView.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						Toast.makeText(MainActivity.this,
									   "Chọn: " + gameNames[index], Toast.LENGTH_SHORT).show();

						Class<?> serviceClass = null;
						switch (index) {
							case 0: serviceClass = FloatingSunwin.class; break;
							case 1: serviceClass = Floating789.class; break;
							case 2: serviceClass = FloatingHit.class; break;
							case 3: serviceClass = FloatingB52.class; break;
							case 4: serviceClass = Floating68gb.class; break;
							case 5: serviceClass = FloatingSum.class; break;
							case 6: serviceClass = FloatingLuck8.class; break;
						}

						if (serviceClass != null) {
							startFloatingServiceWithPermission(serviceClass);
						}
					}
				});

            gridLayout.addView(imageView);
        }
    }

    // 👉 Hàm check & xin quyền overlay
    private void startFloatingServiceWithPermission(Class<?> serviceClass) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
			!Settings.canDrawOverlays(this)) {
            pendingServiceClass = serviceClass;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
									   Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        } else {
            startService(new Intent(MainActivity.this, serviceClass));
        }
    }

    // 👉 Nhận kết quả xin quyền
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
				Settings.canDrawOverlays(this)) {
                if (pendingServiceClass != null) {
                    startService(new Intent(MainActivity.this, pendingServiceClass));
                    pendingServiceClass = null;
                }
            } else {
                Toast.makeText(this,
							   "Bạn phải cấp quyền hiển thị trên ứng dụng khác!",
							   Toast.LENGTH_LONG).show();
            }
        }
    }

    // 👉 Hàm hiện dialog giá
    private void showPriceMenu() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_price, null);

        ListView listView = dialogView.findViewById(R.id.listPrice);

        final int[] priceIcons = {
			R.drawable.ic_vip1,
			R.drawable.ic_vip2,
			R.drawable.ic_vip3,
			R.drawable.ic_vip4,
			R.drawable.ic_vip5,
			R.drawable.ic_vip6
        };

        final String[] priceTexts = {
			"1DAY = 35K",
			"3DAY = 50K",
			"7DAY = 80K",
			"1THÁNG = 150K",
			"3THÁNG = 250K",
			"VĨNH VIỄN = 350K"
        };

        PriceAdapter adapter = new PriceAdapter(this, priceIcons, priceTexts);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					startActivity(new Intent(Intent.ACTION_VIEW,
											 Uri.parse("https://t.me/mrtinhios")));
				}
			});

        LinearLayout admin1 = dialogView.findViewById(R.id.admin1);
        admin1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startActivity(new Intent(Intent.ACTION_VIEW,
											 Uri.parse("https://t.me/mrtinhios")));
				}
			});

        LinearLayout admin2 = dialogView.findViewById(R.id.admin2);
        admin2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startActivity(new Intent(Intent.ACTION_VIEW,
											 Uri.parse("https://t.me/axobantool")));
				}
			});

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.show();
    }
}
