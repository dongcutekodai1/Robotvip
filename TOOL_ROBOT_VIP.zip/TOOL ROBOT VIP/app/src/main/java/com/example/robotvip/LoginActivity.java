package com.example.robotvip;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {

    private EditText edtKey;
    private Button btnLogin;
    private String API_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        API_URL = getString(R.string.api_check_key);

        edtKey = findViewById(R.id.edtKey);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String key = edtKey.getText() != null ? edtKey.getText().toString().trim() : "";
					if (key.isEmpty()) {
						Toast.makeText(LoginActivity.this, "Vui lòng nhập key!", Toast.LENGTH_SHORT).show();
						return;
					}

					String deviceId = Settings.Secure.getString(
                        getContentResolver(),
                        Settings.Secure.ANDROID_ID
					);

					new CheckKeyTask().execute(key, deviceId);
				}
			});
    }

    private class CheckKeyTask extends AsyncTask<String, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(String... params) {
            HttpURLConnection conn = null;
            InputStream is = null;
            OutputStream os = null;
            try {
                String key = params[0];
                String deviceId = params[1];

                URL url = new URL(API_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);

                String body = "{\"key\":\"" + escapeJson(key) + "\",\"device_id\":\"" + escapeJson(deviceId) + "\"}";

                os = conn.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.flush();

                int code = conn.getResponseCode();
                if (code >= 200 && code < 300) {
                    is = conn.getInputStream();
                } else {
                    is = conn.getErrorStream();
                }
                if (is == null) return null;

                BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();

                return new JSONObject(sb.toString());

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            } finally {
                try { if (os != null) os.close(); } catch (Exception ignored) {}
                try { if (is != null) is.close(); } catch (Exception ignored) {}
                if (conn != null) conn.disconnect();
            }
        }

        @Override
        protected void onPostExecute(JSONObject res) {
            if (res == null) {
                Toast.makeText(LoginActivity.this, "Không kết nối được server", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean valid = res.optBoolean("valid", false);
            if (valid) {
                String expire = res.optString("expire", "");
                Toast.makeText(LoginActivity.this, "Đăng nhập thành công!\nHạn: " + expire, Toast.LENGTH_LONG).show();

                // ✅ Lưu trạng thái đã đăng nhập
                SharedPreferences prefs = getSharedPreferences("MyApp", Context.MODE_PRIVATE);
                prefs.edit()
					.putBoolean("isLoggedIn", true) // quan trọng
					.putString("expire", expire)
					.apply();

                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();

            } else {
                String msg = res.optString("message", "Key không hợp lệ");
                Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
