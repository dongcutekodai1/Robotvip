package com.example.robotvip;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class PriceAdapter extends BaseAdapter {

    private Context context;
    private int[] icons;
    private String[] prices;

    public PriceAdapter(Context context, int[] icons, String[] prices) {
        this.context = context;
        this.icons = icons;
        this.prices = prices;
    }

    @Override
    public int getCount() {
        return prices.length;
    }

    @Override
    public Object getItem(int position) {
        return prices[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_price, parent, false);
        }

        ImageView icon = convertView.findViewById(R.id.itemIcon);
        TextView text = convertView.findViewById(R.id.itemText);

        icon.setImageResource(icons[position]);
        text.setText(prices[position]);

        return convertView;
    }
}
