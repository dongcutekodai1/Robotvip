package com.example.robotvip;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public abstract class BaseFloatingService extends Service {

    protected WindowManager windowManager;
    protected View floatingView;
    protected TextView tvLine1, tvLine2;
    protected ImageView btnClose;

    protected Handler handler = new Handler();
    protected ScheduledExecutorService scheduler;
    protected String lastPhien = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Inflate layout nổi
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_robot, null);
        tvLine1 = floatingView.findViewById(R.id.tv_prediction_line1);
        tvLine2 = floatingView.findViewById(R.id.tv_prediction_line2);
        btnClose = floatingView.findViewById(R.id.btnClose);

        // Xử lý nút đóng
        btnClose.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopSelf();
				}
			});

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			layoutFlag,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        // Thêm view nổi
        windowManager.addView(floatingView, params);

        // Cho phép kéo view nổi
        floatingView.setOnTouchListener(new View.OnTouchListener() {
				private int initialX, initialY;
				private float initialTouchX, initialTouchY;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return true;

						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int) (event.getRawX() - initialTouchX);
							params.y = initialY + (int) (event.getRawY() - initialTouchY);
							windowManager.updateViewLayout(floatingView, params);
							return true;
					}
					return false;
				}
			});

        // Scheduler để fetch API
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(new Runnable() {
				@Override
				public void run() {
					try {
						final JSONObject res = GameFetcher.fetchPrediction(getApiUrl());
						if (res == null) return;

						final String phien = res.optString("phien_hien_tai", "");
						final String duDoan = res.optString("du_doan", "");
						final int tinCay = res.optInt("do_tin_cay", 0);

						if (!phien.equals(lastPhien)) {
							lastPhien = phien;

							// Hiện "chờ phiên mới..." và ẩn line2
							runOnUi(new Runnable() {
									@Override
									public void run() {
										if (tvLine1 != null) tvLine1.setText("Chờ phiên mới...");
										if (tvLine2 != null) tvLine2.setVisibility(View.GONE);
									}
								});

							// Delay 20s rồi update kết quả
							handler.postDelayed(new Runnable() {
									@Override
									public void run() {
										final String line1 = "#" + phien + ": " + duDoan;
										final String line2 = "Độ tin cậy: " + tinCay + "%";

										runOnUi(new Runnable() {
												@Override
												public void run() {
													if (tvLine1 != null) tvLine1.setText(line1);
													if (tvLine2 != null) {
														tvLine2.setText(line2);
														tvLine2.setVisibility(View.VISIBLE);
													}
												}
											});
									}
								}, 20000);
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}, 0, 5, TimeUnit.SECONDS);
    }

    protected void runOnUi(Runnable r) {
        handler.post(r);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) windowManager.removeView(floatingView);
        if (scheduler != null) scheduler.shutdown();
    }

    // Subclass phải override
    protected abstract String getApiUrl();
}
