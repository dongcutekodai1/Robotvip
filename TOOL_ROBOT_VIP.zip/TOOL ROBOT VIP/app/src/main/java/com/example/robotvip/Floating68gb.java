package com.example.robotvip;

public class Floating68gb extends BaseFloatingService {
    @Override
    protected String getApiUrl() {
        return "https://tooltxvip.pro/api.php?game=68game";
    }
}
