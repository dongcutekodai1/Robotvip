package com.example.robotvip;

public class FloatingSunwin extends BaseFloatingService {
    @Override
    protected String getApiUrl() {
        return "https://tooltxvip.pro/api.php?game=sunwin";
    }
}
